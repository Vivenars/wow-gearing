# 魔兽世界配装模拟器 · GitHub Pages

纯静态的正式服 12.1.5 配装工具。发布文件为 dist/，包括装备库、原版图标、宝石附魔、食物、种族和职业基础属性、方案导入与导出插件。无需服务器、数据库服务或 API 密钥。

## 首次发布

1. 创建自己的 GitHub 公开空仓库，默认分支使用 main。
2. 将发布包解压后的内容上传至仓库根目录，保留 dist/、scripts/ 和 .github/workflows/pages.yml 的目录结构。不要把 ZIP 文件本身作为网站内容上传。
3. 在仓库 Settings → Pages → Build and deployment 中，将 Source 设为 GitHub Actions。
4. 在 Actions 中运行 Deploy GitHub Pages 工作流。之后推送 main 上的网页更新会自动发布。
5. 发布成功后的实际网址显示在工作流的部署结果和 Settings → Pages 页面，一般为 https://用户名.github.io/仓库名/。

工作流只发布 dist/。发布包不含服务器部署配置、SSH 密钥、Git 历史或登录凭据。源码和数据许可、可复现的生成输入随网页下载包提供，遵循 GPL-3.0-or-later；魔兽世界名称与图标权利归各自权利人。

## 方案迁移与更新

新 GitHub Pages 网址与旧服务器网址使用不同的浏览器存储。请先在旧网址导出方案 JSON，再到新网址导入。所有方案和导入数据仍在浏览器本地处理。

后续更新 dist/ 文件即可。脚本 node scripts/verify-static.mjs 会检查静态文件、原版图标以及 /仓库名/ 子路径下的资源引用。

参考：[GitHub 官方自定义 Pages 工作流文档](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages)。
