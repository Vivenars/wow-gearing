// SPDX-License-Identifier: GPL-3.0-or-later
import {readFileSync,existsSync,readdirSync,statSync} from 'node:fs';
import {resolve,relative,dirname,extname} from 'node:path';
import assert from 'node:assert/strict';
const root=resolve('dist'),prefix='/wow-gearing/',base=new URL('https://example.github.io'+prefix);
let count=0,bytes=0;
function checkReference(from,ref){
 if(/^(?:https?:|data:|blob:|mailto:|#)/.test(ref))return;
 assert(!ref.startsWith('/'),'Root-relative path breaks project Pages: '+ref);
 const source=new URL(relative(root,from).replaceAll('\\','/'),base),url=new URL(ref,source);
 assert(url.pathname.startsWith(prefix),'Path escapes project site: '+ref);
 const target=resolve(root,decodeURIComponent(url.pathname.slice(prefix.length)));
 assert(target===root||target.startsWith(root+'/')||target.startsWith(root+'\\'),'Path escapes static root');
 assert(existsSync(target),'Missing file: '+relative(root,from)+' -> '+ref);
}
function inspect(directory){for(const entry of readdirSync(directory,{withFileTypes:true})){
 const file=resolve(directory,entry.name);assert(!entry.isSymbolicLink(),'Pages artifact must not contain links');
 if(entry.isDirectory()){inspect(file);continue;}count++;bytes+=statSync(file).size;
 if(!['.mjs','.html','.css'].includes(extname(file)))continue;
 const text=readFileSync(file,'utf8');
 const patterns=extname(file)==='.mjs'?[/\bfrom\s*['"]([^'"]+)['"]/g,/\bfetch\(\s*['"]([^'"]+)['"]/g]:extname(file)==='.html'?[/\b(?:src|href)="([^"]+)"/g]:[/url\(['"]?([^)'"\s]+)['"]?\)/g];
 for(const pattern of patterns)for(const match of text.matchAll(pattern))checkReference(file,match[1]);
}}
inspect(root);
for(const file of ['index.html','app.mjs','character.mjs','character-data.mjs','site-info.mjs','simc.mjs','simc-meta.mjs','simc-data.mjs','enhancement-editor.mjs','data/equipment-12.1.5.json','data/enhancements-12.1.5.json','AzerothGearingExport.zip','database-source.zip','enhancements-source.zip'])assert(existsSync(resolve(root,file)),file);
const db=JSON.parse(readFileSync(resolve(root,'data/equipment-12.1.5.json')));
assert.equal(db.meta.build,'12.1.5.70575');assert.equal(db.items.length,db.meta.count);
for(const item of db.items)assert(existsSync(resolve(root,'icons/'+item.iconFileDataId+'.jpg')),'Missing original icon '+item.itemId);
for(const file of ['forever.html','forever-app.mjs','forever-core.mjs','forever.css','InfiniteGearingExport.zip'])assert(existsSync(resolve(root,file)),file);
const forever=JSON.parse(readFileSync(resolve(root,'data/equipment-forever.json')));
assert.equal(forever.meta.edition,'forever');assert.match(forever.meta.build,/^1\.60\./);
assert.equal(new Set(forever.items.map(i=>i.itemId)).size,forever.items.length,'Duplicate Forever item IDs');
for(const icon of new Set(forever.items.map(i=>i.icon).filter(Boolean))){assert.match(icon,/^[a-z0-9_-]+$/i);assert(existsSync(resolve(root,'icons/forever/'+icon+'.jpg')),'Missing Forever icon '+icon);}
assert(bytes<1024**3,'Site exceeds 1 GiB');
console.log(JSON.stringify({result:'PASS',files:count,bytes,projectPath:prefix,items:db.items.length,foreverItems:forever.items.length}));
